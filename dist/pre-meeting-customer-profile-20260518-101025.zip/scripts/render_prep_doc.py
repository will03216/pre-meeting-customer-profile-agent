#!/usr/bin/env python3
"""Render a BytePlus pre-meeting customer profile draft from normalized JSON."""

from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


TBD = "TBD - please confirm"
TO_VALIDATE = "To Validate"


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def parse_dt(value: str, tz_name: str) -> datetime | None:
    if not value:
        return None
    try:
        normalized = value.replace("Z", "+00:00")
        dt = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    tz = ZoneInfo(tz_name or "Europe/London")
    if dt.tzinfo is None:
        return dt.replace(tzinfo=tz)
    return dt.astimezone(tz)


def val(value, fallback: str = TBD) -> str:
    if value is None:
        return fallback
    if isinstance(value, str):
        return value.strip() or fallback
    if isinstance(value, list):
        return "\n".join(str(v).strip() for v in value if str(v).strip()) or fallback
    return str(value)


def person_text(person: dict | None) -> str:
    if not person:
        return TBD
    name = person.get("name") or person.get("email")
    email = person.get("email")
    if name and email and name != email:
        return f"{name} ({email})"
    return val(name or email)


def likely_list(items, fallback: str = TO_VALIDATE) -> str:
    if not items:
        return fallback
    return "\n".join(f"Likely: {item} (?)" for item in items)


def known_or_likely(value: str | list | None, confidence: str | None, fallback: str = TO_VALIDATE) -> str:
    if not value:
        return fallback
    prefix = "Known" if confidence == "high" else "Likely"
    suffix = "" if confidence == "high" else " (?)"
    if isinstance(value, list):
        text = "; ".join(str(v) for v in value if v)
    else:
        text = str(value)
    return f"{prefix}: {text}{suffix}"


def table(rows: list[tuple[str, str]]) -> str:
    out = ["| Field | Value |", "| --- | --- |"]
    for k, v in rows:
        cell = val(v).replace("\n", "<br>")
        out.append(f"| {k} | {cell} |")
    return "\n".join(out)


def output_table(rows: list[tuple[str, str]]) -> str:
    out = ["| Category | Notes |", "| --- | --- |"]
    for k, v in rows:
        out.append(f"| {k} | {val(v, TO_VALIDATE).replace(chr(10), '<br>')} |")
    return "\n".join(out)


def source_attribution(data: dict) -> str:
    prior_docs = data.get("prior_docs") or []
    prior_notes = data.get("prior_notes") or []
    search_results = data.get("search_results") or []
    enrichment = data.get("enrichment") or {}

    source_status = data.get("source_status") or {}
    used = ["calendar data"] if source_status.get("calendar") == "available" else ["user-provided customer identity"]
    if prior_docs:
        used.append("prior docs")
    if prior_notes:
        used.append("prior AI Notes / Minutes")
    enrichment_source = enrichment.get("source")
    if enrichment.get("available") and enrichment_source != "web_search":
        used.append("MCP enrichment")
    web_results = [item for item in search_results if item.get("source") == "web"]
    kb_results = [item for item in search_results if item.get("source") != "web"]
    if web_results:
        used.append("web search references")
    if kb_results:
        used.append("Mira / Knowledge Base references")

    if used == ["calendar data"]:
        return "Prep generated from calendar data only. Prior docs, MCP enrichment, web search, and Mira/Knowledge Base references were unavailable in this run."
    return "Prep generated from " + ", ".join(used) + "."


def derive_questions(data: dict) -> list[str]:
    enrichment = data.get("enrichment") or {}
    questions = list(enrichment.get("suggested_questions") or [])
    defaults = [
        "Can you confirm the main AI workload you are evaluating BytePlus for?",
        "What is your current model / vendor stack?",
        "What are your latency, compliance, or data residency requirements?",
        "Who owns the technical and commercial decision?",
        "Is there a defined POC timeline or success metric?",
        "What would make the POC successful from your perspective?",
    ]
    for q in defaults:
        if q not in questions:
            questions.append(q)
    return questions[:8]


def render(data: dict) -> str:
    meeting = data.get("meeting") or {}
    customer = data.get("customer") or {}
    enrichment = data.get("enrichment") or {}
    known = data.get("known") or {}
    source_status = data.get("source_status") or {}
    tz_name = meeting.get("timezone") or "Europe/London"
    start = parse_dt(meeting.get("start", ""), tz_name)
    end = parse_dt(meeting.get("end", ""), tz_name)
    date_label = start.strftime("%d-%m-%Y") if start else TBD
    time_label = (
        f"{start.strftime('%H:%M')}-{end.strftime('%H:%M')}, {tz_name}"
        if start and end
        else TBD
    )
    customer_name = val(customer.get("name"), "<unknown> (please confirm)")
    company_name = customer.get("company_name")
    title = f"BytePlus <> {customer_name} - {date_label} - Pre-Meeting Prep"
    confidence = customer.get("confidence") or enrichment.get("confidence")

    attendees = data.get("attendees") or []
    stakeholders = []
    for attendee in attendees:
        if not attendee.get("external", True):
            continue
        text = person_text(attendee)
        if attendee.get("title"):
            text = f"{text} - {attendee['title']}"
        stakeholders.append(text)

    prior_docs = data.get("prior_docs") or []
    prior_notes = data.get("prior_notes") or []
    search_results = data.get("search_results") or []
    product_fit = enrichment.get("possible_byteplus_fit") or []
    product_fit_text = []
    for item in product_fit:
        product = item.get("product") or "BytePlus product"
        reason = item.get("reason")
        fit_conf = item.get("confidence")
        prefix = "Known" if fit_conf == "high" else "Likely"
        suffix = "" if fit_conf == "high" else " (?)"
        product_fit_text.append(f"{prefix}: {product}{suffix}" + (f" - {reason}" if reason else ""))

    background_rows = [
        ("Client Name/Nation", f"{customer_name}" + (f"\nLikely company: {company_name} (?)" if company_name else "") + f"\n{val(customer.get('hq'), TO_VALIDATE)}"),
        ("AE", person_text(meeting.get("organizer"))),
        ("SA", person_text(meeting.get("sa"))),
        ("Domain/Industry", f"{val(customer.get('domain'), TO_VALIDATE)}\n{known_or_likely(customer.get('industry'), confidence)}"),
        ("Stakeholders", "\n".join(stakeholders) or TBD),
        ("Key Use Case", known_or_likely(enrichment.get("known_use_cases"), None)),
        ("Servicing Region(s)", known_or_likely(customer.get("hq"), confidence)),
        ("Objectives", val(known.get("objectives"), "To Validate: customer objectives")),
        ("Risk", likely_list(enrichment.get("known_risks"), "To Validate: risks and blockers")),
        ("Competitor", likely_list(enrichment.get("known_competitors"), "To Validate: current vendors / competitors")),
        ("Reference", val(meeting.get("url"), "Calendar event link unavailable")),
    ]

    questions = derive_questions(data)
    engagement_rows = ["| Date | Stage | Key Information | Next Step |", "| --- | --- | --- | --- |"]
    imported = False
    for doc in sorted(prior_docs, key=lambda d: d.get("date", ""), reverse=True):
        for row in doc.get("engagement_rows") or []:
            engagement_rows.append(
                f"| {val(row.get('date'), val(doc.get('date')))} | {val(row.get('stage'))} | {val(row.get('key_information'))} | {val(row.get('next_step'))} |"
            )
            imported = True
    if not imported:
        engagement_rows.append("| - | - | No prior BytePlus customer profile found. | - |")
    engagement_rows.append(
        f"| {date_label} | Pre-Meeting | {source_attribution(data)} | Validate assumptions during the customer meeting; update after AI Notes / Minutes are available. |"
    )

    output_rows = [
        ("Customer Stage", "Known: Pre-Meeting"),
        ("Core Business", known_or_likely(customer.get("description") or customer.get("industry"), confidence)),
        ("Main AI Use Cases", known_or_likely(enrichment.get("known_use_cases"), None)),
        ("Current Models", val(known.get("current_models"), "To Validate: current models")),
        ("Current Vendors", val(known.get("current_vendors"), "To Validate: current vendors")),
        ("Monthly Volume", val(known.get("monthly_volume"), "To Validate: monthly tokens / spend / usage")),
        ("Paid Users", val(known.get("paid_users"), "To Validate: paid users / DAU / MAU")),
        ("Pain Points", val(known.get("pain_points"), likely_list(enrichment.get("known_risks"), "To Validate: pain points"))),
        ("Budget Status", val(known.get("budget_status"), "To Validate: budget status")),
        ("Contract / Commitment", val(known.get("contract_commitment"), "To Validate: contract / commitment")),
        ("POC Timeline", val(known.get("poc_timeline"), "To Validate: POC timeline")),
        ("Expansion Opportunity", "\n".join(product_fit_text) or "To Validate: expansion opportunity"),
        ("Competitor Risk", likely_list(enrichment.get("known_competitors"), "To Validate: competitor risk")),
        ("Cross-Sell Potential", "\n".join(product_fit_text) or "Likely: Doubao / Seed LLM; possible Vision / RTC depending on workflow (?)"),
        ("Next Action", "To Validate: decision-maker, POC success metric, and next step"),
    ]

    refs = []
    if meeting.get("url"):
        refs.append(f"- Calendar event: {meeting['url']}")
    refs.append("- Prior Customer Profile docs: " + (", ".join(d.get("url", d.get("title", "")) for d in prior_docs) if prior_docs else "No prior customer profile found."))
    refs.append("- Prior AI Notes / Minutes: " + (", ".join(n.get("url", n.get("title", "")) for n in prior_notes) if prior_notes else "No prior AI Notes found."))
    web_results = [r for r in search_results if r.get("source") == "web"]
    kb_results = [r for r in search_results if r.get("source") != "web"]
    refs.append("- Web search results: " + (", ".join(r.get("url", r.get("label", "")) for r in web_results) if web_results else "No web search references found."))
    refs.append("- Mira / Knowledge Base search results: " + (", ".join(r.get("url", r.get("label", "")) for r in kb_results) if kb_results else "No Mira / Knowledge Base references found."))
    source_links = enrichment.get("source_links") or []
    enrichment_label = "Web enrichment source" if enrichment.get("source") == "web_search" else "Enriched profile source"
    refs.append(f"- {enrichment_label}: " + (", ".join(s.get("url", s.get("label", "")) for s in source_links) if source_links else "MCP enrichment unavailable or no source link allowed."))

    unavailable = [f"{k}: {v}" for k, v in source_status.items() if str(v).lower() not in {"available", "ok"}]
    if not unavailable and not enrichment.get("available", False):
        unavailable.append("mcp: unavailable")

    return "\n\n".join(
        [
            f"# {title}",
            table(
                [
                    ("Customer", customer_name),
                    ("Meeting Date", date_label),
                    ("Time", time_label),
                    ("AE / Owner", person_text(meeting.get("organizer"))),
                    ("SA", person_text(meeting.get("sa"))),
                    ("Status", "Pre-Meeting Prep - to validate in customer meeting"),
                ]
            ),
            "## 1. Background\n\n" + table(background_rows),
            "## 2. Live Interview Script / Standard Question Prompt\n\n"
            + "### Suggested Questions for This Meeting\n\n"
            + "\n".join(f"{idx}. {q}" for idx, q in enumerate(questions, 1))
            + "\n\n### Static Master Script\n\nUse the master template blocks from `references/master-template.md`: Standard Discovery, AI Usage & Current Stack, Business Scenarios & Use Cases, Pain Point Discovery, POC Qualification, Commercial & Procurement Signals, Cross-Sell / Upsell Discovery, and Competitive Replacement Questions.",
            "## 3. Client Engagement Log\n\n" + "\n".join(engagement_rows),
            "## 4. Meeting Output Template / To-Validate Output\n\n" + output_table(output_rows),
            "## 5. Risk & Support\n\n"
            + "### Risks\n\n"
            + (("\n".join(f"- {risk} (?) - validate in meeting." for risk in enrichment.get("known_risks", []))) or "- To Validate: budget owner, decision process, technical owner, timeline, and blockers.")
            + "\n\n### Case Study (domestic / overseas)\n\n*What you need | For which stakeholder / use case | Domestic or overseas | By when*"
            + "\n\n### Pricing Proposal\n\n*Volume | Commitment term | Models | Competitor price to beat | By when*"
            + "\n\n### Solution Proposal\n\n*What the customer is building | BytePlus products in scope | Technical concerns | Format | By when*",
            "## 6. Reference\n\n" + "\n".join(refs),
            "## Run Report\n\n"
            + ("Unavailable or incomplete sources:\n" + "\n".join(f"- {item}" for item in unavailable) if unavailable else "All declared sources available."),
        ]
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="Normalized event context JSON")
    parser.add_argument("--output", type=Path, help="Markdown output path; stdout when omitted")
    args = parser.parse_args()

    data = load_json(args.input)
    rendered = render(data)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    else:
        print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
