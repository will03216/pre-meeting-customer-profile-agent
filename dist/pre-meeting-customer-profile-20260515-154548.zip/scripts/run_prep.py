#!/usr/bin/env python3
"""Portable orchestration CLI for BytePlus pre-meeting prep.

This script runs with the current user's local Lark CLI authentication. It
keeps all optional integrations best-effort so the skill remains useful from a
fresh zip install and in dry-run mode.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

try:
    from render_prep_doc import render
except ImportError:  # pragma: no cover - defensive for unusual launch paths
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from render_prep_doc import render


REPO_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = REPO_ROOT / "outputs" / "prep"
DEFAULT_CALENDAR_ID = os.getenv("LARK_CALENDAR_ID", "primary")
DEFAULT_TIMEZONE = os.getenv("DEFAULT_TIMEZONE", "Europe/London")
INTERNAL_DOMAINS = {
    item.strip().lower()
    for item in os.getenv(
        "INTERNAL_EMAIL_DOMAINS",
        "bytedance.com,byteplus.com,lark.com,larksuite.com,feishu.cn",
    ).split(",")
    if item.strip()
}
PERSONAL_EMAIL_DOMAINS = {
    "gmail.com",
    "googlemail.com",
    "yahoo.com",
    "outlook.com",
    "hotmail.com",
    "live.com",
    "icloud.com",
    "me.com",
    "proton.me",
    "protonmail.com",
    "qq.com",
    "163.com",
    "126.com",
}
INTERNAL_TITLE_PATTERNS = [
    "standup",
    "sync",
    "1:1",
    "one-on-one",
    "internal",
    "weekly",
    "daily",
    "retro",
    "retrospective",
    "planning",
    "team meeting",
    "all hands",
    "review",
    "catch up",
]


@dataclass
class PrepInput:
    mode: str
    value: str | None
    window: str | None


@dataclass
class CustomerIdentity:
    canonical_name: str | None
    domain: str | None
    email: str | None
    confidence: str
    evidence: list[str]


@dataclass
class PrepContext:
    customer: CustomerIdentity
    event: dict[str, Any] | None
    prior_docs: list[dict[str, Any]]
    enrichment: dict[str, Any] | None
    missing_context: list[str]


@dataclass
class PrepResult:
    doc_title: str
    doc_url: str | None
    mode: str
    customer_name: str | None
    confidence: str
    missing_context: list[str]


class PrepError(RuntimeError):
    """User-facing orchestration error."""


def debug_log(enabled: bool, message: str) -> None:
    if enabled:
        print(f"[debug] {message}", file=sys.stderr)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--event-id")
    modes.add_argument("--customer")
    modes.add_argument("--domain")
    modes.add_argument("--email")
    modes.add_argument("--window")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--output-json", action="store_true")
    parser.add_argument("--create-doc", action="store_true", help="Explicitly allow new doc creation; this is the default outside dry-run.")
    parser.add_argument("--update-existing", action="store_true")
    parser.add_argument("--no-notify", action="store_true")
    parser.add_argument("--debug", action="store_true")
    return parser.parse_args(argv)


def prep_input_from_args(args: argparse.Namespace) -> PrepInput:
    for mode in ("event_id", "customer", "domain", "email", "window"):
        value = getattr(args, mode)
        if value:
            return PrepInput(mode=mode.replace("_", "-"), value=value, window=value if mode == "window" else None)
    raise PrepError("No input mode supplied.")


def require_lark_cli() -> str:
    path = shutil.which("lark-cli")
    if not path:
        raise PrepError(
            "lark-cli is not installed or is not on PATH. Install/configure Lark CLI, "
            "then run `lark-cli auth login` with the required scopes."
        )
    return path


def run_lark(args: list[str], *, debug: bool = False, check: bool = False) -> dict[str, Any]:
    require_lark_cli()
    cmd = ["lark-cli", *args]
    debug_log(debug, "running: " + " ".join(safe_arg(a) for a in cmd))
    proc = subprocess.run(cmd, text=True, capture_output=True, check=False)
    output = proc.stdout.strip() or proc.stderr.strip()
    try:
        data = json.loads(output) if output else {}
    except json.JSONDecodeError:
        data = {"ok": proc.returncode == 0, "raw": output}
    if check and proc.returncode != 0:
        raise PrepError(format_lark_error(data, proc.returncode))
    if proc.returncode != 0 and "ok" not in data:
        data["ok"] = False
    return data


def safe_arg(arg: str) -> str:
    if "TOKEN" in arg.upper() or "SECRET" in arg.upper():
        return "<redacted>"
    return arg


def format_lark_error(data: dict[str, Any], returncode: int) -> str:
    err = data.get("error") or {}
    msg = err.get("message") or data.get("message") or data.get("raw") or f"lark-cli failed with exit {returncode}"
    hint = err.get("hint")
    if hint:
        return f"{msg}\nNext: {hint}"
    return str(msg)


def infer_missing_scope(message: str) -> str | None:
    lowered = message.lower()
    scope_map = [
        ("calendar", "calendar:calendar.event:read"),
        ("docx", "docx:document:create or docx:document:write_only"),
        ("document", "docx:document:create or docx:document:write_only"),
        ("docs", "search:docs:read or docx document scopes"),
        ("search", "search:docs:read"),
        ("im", "im:message"),
        ("message", "im:message"),
        ("permission", "permission/scope not specific in Lark response"),
        ("scope", "scope not specific in Lark response"),
    ]
    for needle, scope in scope_map:
        if needle in lowered:
            return scope
    return None


def mask_token(token: str | None) -> str:
    if not token:
        return "none"
    if len(token) <= 8:
        return "<configured>"
    return f"{token[:4]}...{token[-4:]}"


def auth_status(debug: bool = False) -> dict[str, Any] | None:
    try:
        data = run_lark(["auth", "status"], debug=debug)
    except PrepError:
        return None
    if data.get("tokenStatus") == "valid":
        return data
    return None


def parse_email(value: str) -> tuple[str, str] | None:
    match = re.match(r"^[^@\s]+@([^@\s]+\.[^@\s]+)$", value.strip().lower())
    if not match:
        return None
    return value.strip().lower(), match.group(1)


def is_personal_domain(domain: str | None) -> bool:
    return bool(domain and domain.lower() in PERSONAL_EMAIL_DOMAINS)


def is_internal_domain(domain: str | None) -> bool:
    return bool(domain and domain.lower() in INTERNAL_DOMAINS)


def domain_to_name(domain: str | None) -> str | None:
    if not domain:
        return None
    root = domain.split(".")[0].replace("-", " ").replace("_", " ").strip()
    return root.title() if root else None


def normalize_domain(value: str | None) -> str | None:
    if not value:
        return None
    cleaned = value.strip().lower()
    cleaned = re.sub(r"^https?://", "", cleaned)
    cleaned = cleaned.split("/")[0]
    cleaned = cleaned[4:] if cleaned.startswith("www.") else cleaned
    return cleaned or None


def external_attendee_domains(event: dict[str, Any] | None) -> list[tuple[str, str]]:
    if not event:
        return []
    domains: list[tuple[str, str]] = []
    for attendee in event.get("attendees") or []:
        email = attendee.get("third_party_email") or attendee.get("email") or ""
        parsed = parse_email(email)
        if not parsed:
            continue
        _, domain = parsed
        if not is_internal_domain(domain) and not is_personal_domain(domain):
            domains.append((email, domain))
    return domains


def title_customer_candidate(title: str) -> str | None:
    cleaned = title.strip()
    patterns = [
        r"^(?:byteplus|bytedance|byte)\s*<>\s*(.+?)(?:\s+(?:sync|intro|discovery|call))?$",
        r"^(.+?)\s*<>\s*(?:byteplus|bytedance|byte)(?:\s+.*)?$",
        r"^customer call:\s*(.+?)\s*(?:x|&|and|<>|/)\s*(?:byteplus|bytedance|byte).*$",
        r"^(.+?)\s*(?:x|&|and|/)\s*(?:byteplus|bytedance|byte)(?:\s+.*)?$",
    ]
    for pattern in patterns:
        match = re.match(pattern, cleaned, re.IGNORECASE)
        if match:
            return cleanup_customer_name(match.group(1))
    return None


def cleanup_customer_name(value: str | None) -> str | None:
    if not value:
        return None
    cleaned = re.sub(r"\b(sync|intro|discovery|call|meeting)\b", "", value, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" -:|/")
    return cleaned or None


def resolve_customer(
    *,
    explicit_customer: str | None = None,
    explicit_domain: str | None = None,
    explicit_email: str | None = None,
    event: dict[str, Any] | None = None,
) -> CustomerIdentity:
    evidence: list[str] = []
    email: str | None = None
    domain = normalize_domain(explicit_domain)
    name = cleanup_customer_name(explicit_customer)
    confidence = "unknown"

    if name:
        evidence.append(f"explicit customer input: {name}")
        confidence = "confirmed"
    if domain:
        evidence.append(f"explicit domain input: {domain}")
        confidence = "confirmed"
        name = name or domain_to_name(domain)

    if explicit_email:
        parsed = parse_email(explicit_email)
        if parsed:
            email, email_domain = parsed
            evidence.append(f"explicit email input: {email}")
            if is_personal_domain(email_domain):
                evidence.append(f"personal email domain ignored for company inference: {email_domain}")
            else:
                domain = domain or email_domain
                name = name or domain_to_name(email_domain)
                evidence.append(f"corporate email domain: {email_domain}")
                confidence = "confirmed"

    for attendee_email, attendee_domain in external_attendee_domains(event):
        domain = domain or attendee_domain
        name = name or domain_to_name(attendee_domain)
        evidence.append(f"attendee email domain: {attendee_domain} ({attendee_email})")
        confidence = "confirmed"
        break

    if event and not name:
        candidate = title_customer_candidate(event.get("summary") or event.get("title") or "")
        if candidate:
            name = candidate
            evidence.append(f"title customer candidate: {candidate}")
            confidence = "likely" if confidence == "unknown" else confidence

    if name and confidence == "unknown":
        confidence = "likely"
    return CustomerIdentity(name, domain, email, confidence, evidence)


def parse_window(value: str, tz_name: str = DEFAULT_TIMEZONE, now: datetime | None = None) -> tuple[datetime, datetime, str]:
    tz = ZoneInfo(tz_name)
    current = now.astimezone(tz) if now else datetime.now(tz)
    today = current.date()
    if value == "today":
        start_day = today
        end_day = today + timedelta(days=1)
    elif value == "tomorrow":
        start_day = today + timedelta(days=1)
        end_day = today + timedelta(days=2)
    elif value == "next-7-days":
        start = current
        end = current + timedelta(days=7)
        return start, end, tz_name
    elif re.match(r"^past-\d+-hours$", value):
        hours = int(value.removeprefix("past-").removesuffix("-hours"))
        if hours <= 0:
            raise PrepError("Past-hour windows must be greater than zero.")
        start = current - timedelta(hours=hours)
        return start, current, tz_name
    elif re.match(r"^\d{4}-\d{2}-\d{2}:\d{4}-\d{2}-\d{2}$", value):
        raw_start, raw_end = value.split(":", 1)
        start_day = date.fromisoformat(raw_start)
        end_day = date.fromisoformat(raw_end)
    else:
        raise PrepError("Unsupported --window value. Use today, tomorrow, next-7-days, past-N-hours, or YYYY-MM-DD:YYYY-MM-DD.")
    return datetime.combine(start_day, time.min, tz), datetime.combine(end_day, time.min, tz), tz_name


def lark_time_to_iso(value: dict[str, Any] | None, fallback_tz: str = DEFAULT_TIMEZONE) -> str:
    if not value:
        return ""
    if value.get("timestamp"):
        tz = ZoneInfo(value.get("timezone") or fallback_tz)
        return datetime.fromtimestamp(int(value["timestamp"]), tz).isoformat()
    if value.get("date"):
        return value["date"]
    return ""


def fetch_event(event_id: str, debug: bool = False) -> dict[str, Any] | None:
    params = {
        "calendar_id": DEFAULT_CALENDAR_ID,
        "event_id": event_id,
        "need_attendee": True,
        "max_attendee_num": 50,
    }
    data = run_lark(
        ["calendar", "events", "get", "--params", json.dumps(params), "--as", "user", "--format", "json"],
        debug=debug,
    )
    if data.get("code") == 0:
        return data.get("data", {}).get("event")
    raise PrepError("Could not fetch Lark event. " + format_lark_error(data, 1))


def fetch_window_events(start: datetime, end: datetime, debug: bool = False) -> list[dict[str, Any]]:
    params = {
        "calendar_id": DEFAULT_CALENDAR_ID,
        "start_time": str(int(start.timestamp())),
        "end_time": str(int(end.timestamp())),
    }
    data = run_lark(
        ["calendar", "events", "instance_view", "--params", json.dumps(params), "--page-all", "--format", "json"],
        debug=debug,
    )
    if data.get("code") == 0:
        return data.get("data", {}).get("items") or []
    raise PrepError("Could not fetch Lark calendar window. " + format_lark_error(data, 1))


def search_docs(queries: list[str], debug: bool = False) -> tuple[list[dict[str, Any]], str | None]:
    docs: list[dict[str, Any]] = []
    seen: set[str] = set()
    for query in [q for q in queries if q]:
        data = run_lark(["docs", "+search", "--query", query, "--format", "json"], debug=debug)
        if data.get("ok") is False or data.get("code") not in (0, None):
            return docs, "Docs search unavailable due to permission or missing scope. Continuing without prior docs."
        items = data.get("data", {}).get("items") or data.get("items") or []
        for item in items:
            token = str(item.get("token") or item.get("doc_id") or item.get("url") or item.get("title"))
            if token and token not in seen:
                seen.add(token)
                docs.append(normalize_doc_result(item))
    return docs[:10], None


def normalize_doc_result(item: dict[str, Any]) -> dict[str, Any]:
    title = item.get("title") or item.get("name") or item.get("docs_title") or "Untitled"
    url = item.get("url") or item.get("docs_url") or item.get("app_link") or ""
    return {"title": title, "url": url, "date": item.get("create_time") or item.get("update_time") or ""}


def is_likely_prep_doc(doc: dict[str, Any], customer_name: str | None) -> bool:
    title = (doc.get("title") or "").lower()
    if customer_name and customer_name.lower() not in title:
        return False
    return "pre-meeting prep" in title or "customer profile" in title or "prep" in title


def choose_existing_doc(docs: list[dict[str, Any]], customer_name: str | None) -> dict[str, Any] | None:
    for doc in docs:
        if is_likely_prep_doc(doc, customer_name):
            return doc
    return None


def classify_event(event: dict[str, Any], explicit_identity: CustomerIdentity | None = None) -> tuple[bool, str]:
    title = (event.get("summary") or "").lower()
    has_external_domain = bool(external_attendee_domains(event))
    has_customer_signal = has_external_domain or bool(title_customer_candidate(event.get("summary") or ""))
    if explicit_identity and explicit_identity.canonical_name:
        lowered = explicit_identity.canonical_name.lower()
        has_customer_signal = has_customer_signal or lowered in title
    if any(pattern in title for pattern in INTERNAL_TITLE_PATTERNS) and not has_customer_signal:
        return False, "internal/generic title without customer signal"
    if has_customer_signal:
        return True, "customer signal found"
    return False, "no external corporate attendee or customer signal"


def call_mcp_enrichment(context: PrepContext, debug: bool = False) -> dict[str, Any] | None:
    url = os.getenv("MCP_CUSTOMER_ENRICHMENT_URL")
    token = os.getenv("MCP_CUSTOMER_ENRICHMENT_TOKEN")
    if not url:
        debug_log(debug, "MCP_CUSTOMER_ENRICHMENT_URL not configured; skipping enrichment")
        return None
    payload = {
        "customer_name": context.customer.canonical_name,
        "domain": context.customer.domain,
        "email": context.customer.email,
        "event": context.event or {},
        "prior_docs_summary": context.prior_docs[:5],
    }
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        debug_log(debug, f"MCP enrichment failed: {exc}")
        context.missing_context.append("MCP enrichment configured but request failed")
        return None


def build_context(
    prep_input: PrepInput,
    *,
    event: dict[str, Any] | None,
    debug: bool = False,
) -> PrepContext:
    explicit_customer = prep_input.value if prep_input.mode == "customer" else None
    explicit_domain = prep_input.value if prep_input.mode == "domain" else None
    explicit_email = prep_input.value if prep_input.mode == "email" else None
    identity = resolve_customer(
        explicit_customer=explicit_customer,
        explicit_domain=explicit_domain,
        explicit_email=explicit_email,
        event=event,
    )
    missing: list[str] = []
    if not event:
        missing.append("meeting context")
    if identity.confidence in {"weak", "unknown"}:
        missing.append("confirmed customer identity")

    search_terms = [
        identity.canonical_name,
        identity.domain,
        f"{identity.canonical_name} AI notes" if identity.canonical_name else None,
        f"{identity.canonical_name} meeting notes" if identity.canonical_name else None,
        f"{identity.canonical_name} customer profile" if identity.canonical_name else None,
        f"{identity.canonical_name} prep" if identity.canonical_name else None,
    ]
    prior_docs, search_warning = search_docs([t for t in search_terms if t], debug=debug)
    if search_warning:
        missing.append(search_warning)

    context = PrepContext(identity, event, prior_docs, None, missing)
    context.enrichment = call_mcp_enrichment(context, debug=debug)
    if context.enrichment is None:
        context.missing_context.append("MCP enrichment unavailable")
    return context


def context_to_renderer_json(context: PrepContext) -> dict[str, Any]:
    event = context.event or {}
    customer = context.customer
    enrichment = normalize_enrichment(context.enrichment, context)
    attendees = []
    for attendee in event.get("attendees") or []:
        email = attendee.get("third_party_email") or attendee.get("email") or ""
        attendees.append(
            {
                "name": attendee.get("display_name") or email,
                "email": email,
                "external": bool(attendee.get("is_external") or attendee.get("type") == "third_party"),
            }
        )
    if customer.email and not attendees:
        attendees.append({"name": customer.email, "email": customer.email, "external": True})

    meeting = {
        "title": event.get("summary") or "Customer prep",
        "start": lark_time_to_iso(event.get("start_time")),
        "end": lark_time_to_iso(event.get("end_time")),
        "timezone": (event.get("start_time") or {}).get("timezone") or DEFAULT_TIMEZONE,
        "organizer": {"name": (event.get("event_organizer") or {}).get("display_name", ""), "email": ""},
        "sa": {"name": "", "email": ""},
        "url": event.get("app_link") or (event.get("vchat") or {}).get("meeting_url") or "",
    }
    return {
        "meeting": meeting,
        "customer": {
            "name": customer.canonical_name or "<unknown> (please confirm)",
            "domain": customer.domain or "",
            "website": enrichment.get("website", ""),
            "industry": enrichment.get("industry", ""),
            "hq": enrichment.get("hq", ""),
            "company_size": enrichment.get("company_size", ""),
            "description": enrichment.get("description", ""),
            "confidence": "high" if customer.confidence == "confirmed" else customer.confidence,
        },
        "attendees": attendees,
        "enrichment": enrichment,
        "prior_docs": context.prior_docs,
        "prior_notes": [],
        "search_results": [],
        "known": {},
        "source_status": {
            "calendar": "available" if event else "missing",
            "attendees": "available" if attendees else "missing",
            "mcp": "available" if context.enrichment else "unavailable",
            "prior_docs": "available" if context.prior_docs else "none",
            "docs_search": "available" if not any("Docs search unavailable" in x for x in context.missing_context) else "unavailable",
        },
    }


def normalize_enrichment(enrichment: dict[str, Any] | None, context: PrepContext) -> dict[str, Any]:
    if not enrichment:
        return {
            "available": False,
            "confidence": context.customer.confidence,
            "known_use_cases": ["To Validate: customer use case"],
            "known_competitors": [],
            "known_risks": ["Missing confirmed budget, decision maker, timeline, current vendor, and success metrics"],
            "possible_byteplus_fit": [
                {"product": "Seed / Doubao LLM", "reason": "Validate AI workload and model requirements", "confidence": "medium"},
                {"product": "Ark / model platform", "reason": "Validate model evaluation, deployment, and routing needs", "confidence": "medium"},
            ],
            "suggested_questions": [],
            "source_links": [],
        }
    return {
        "available": True,
        "confidence": enrichment.get("confidence") or context.customer.confidence,
        "known_use_cases": enrichment.get("known_use_cases") or enrichment.get("use_cases") or [],
        "known_competitors": enrichment.get("known_competitors") or enrichment.get("competitors") or [],
        "known_risks": enrichment.get("known_risks") or enrichment.get("risks") or [],
        "possible_byteplus_fit": enrichment.get("possible_byteplus_fit") or enrichment.get("recommended_products") or [],
        "suggested_questions": enrichment.get("suggested_questions") or enrichment.get("questions_to_ask") or [],
        "source_links": enrichment.get("source_links") or [],
        "website": enrichment.get("website", ""),
        "industry": enrichment.get("industry", ""),
        "hq": enrichment.get("hq", ""),
        "company_size": enrichment.get("company_size", ""),
        "description": enrichment.get("description", ""),
    }


def doc_title(render_json: dict[str, Any]) -> str:
    customer = render_json.get("customer", {}).get("name") or "<unknown> (please confirm)"
    start = render_json.get("meeting", {}).get("start")
    label = "TBD"
    if start:
        try:
            label = datetime.fromisoformat(start).strftime("%d-%m-%Y")
        except ValueError:
            pass
    return f"BytePlus <> {customer} - {label} - Pre-Meeting Prep"


def write_local_outputs(render_json: dict[str, Any], markdown: str, title: str) -> tuple[Path, Path]:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-") or "prep"
    json_path = OUTPUT_ROOT / f"{slug}.json"
    md_path = OUTPUT_ROOT / f"{slug}.md"
    json_path.write_text(json.dumps(render_json, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    md_path.write_text(markdown + "\n", encoding="utf-8")
    return json_path, md_path


def lark_markdown_arg(path: Path) -> str:
    try:
        relative = path.resolve().relative_to(Path.cwd().resolve())
        return f"@{relative.as_posix()}"
    except ValueError:
        return f"@{path}"


def create_or_update_doc(
    *,
    markdown_path: Path,
    title: str,
    existing_doc: dict[str, Any] | None,
    args: argparse.Namespace,
    debug: bool = False,
) -> tuple[str | None, str]:
    if args.dry_run:
        return None, "dry-run: no Lark write"
    fallback_written = markdown_path.exists() and markdown_path.stat().st_size > 0
    markdown_arg = lark_markdown_arg(markdown_path)
    if args.update_existing and existing_doc and existing_doc.get("url"):
        data = run_lark(
            [
                "docs",
                "+update",
                "--doc",
                existing_doc["url"],
                "--markdown",
                markdown_arg,
                "--mode",
                "overwrite",
                "--new-title",
                title,
                "--as",
                "user",
            ],
            debug=debug,
        )
        if data.get("ok"):
            return existing_doc.get("url"), "updated existing doc"
        message = format_lark_error(data, 1)
        status = auth_status(debug=debug)
        diagnostic = [
            "Could not update existing Lark doc; local markdown output created instead.",
            f"Lark CLI auth exists: {'yes' if status else 'no'}",
            f"Likely missing scope: {infer_missing_scope(message) or 'unknown'}",
            "Folder token attempted: none (existing document update)",
            f"Fallback markdown written successfully: {'yes' if fallback_written else 'no'}",
        ]
        return None, "\n".join(diagnostic)

    folder = os.getenv("PREP_DOC_FOLDER_TOKEN") or os.getenv("CUSTOMER_PROFILE_FOLDER_TOKEN")
    cmd = ["docs", "+create", "--title", title, "--markdown", markdown_arg, "--as", "user"]
    if folder:
        cmd[2:2] = ["--folder-token", folder]
    data = run_lark(cmd, debug=debug)
    if data.get("ok"):
        return data.get("data", {}).get("doc_url"), "created Lark doc"
    first_error = format_lark_error(data, 1)
    if folder:
        fallback = run_lark(["docs", "+create", "--title", title, "--markdown", markdown_arg, "--as", "user"], debug=debug)
        if fallback.get("ok"):
            return fallback.get("data", {}).get("doc_url"), "created Lark doc in default space after folder fallback"
        first_error = first_error + " | default-space fallback: " + format_lark_error(fallback, 1)
    status = auth_status(debug=debug)
    diagnostic = [
        "Could not create Lark doc due to missing permission or auth. Local markdown output created instead.",
        f"Lark CLI auth exists: {'yes' if status else 'no'}",
        f"Likely missing scope: {infer_missing_scope(first_error) or 'unknown'}",
        f"Folder token attempted: {mask_token(folder)}",
        f"Fallback markdown written successfully: {'yes' if fallback_written else 'no'}",
    ]
    return None, "\n".join(diagnostic)


def valid_lark_open_id(value: str | None) -> bool:
    return bool(value and re.match(r"^ou_[A-Za-z0-9_-]{8,}$", value))


def build_notification_markdown(result: PrepResult) -> str:
    return (
        f"Meeting prep generated.\n\n"
        f"Customer: {result.customer_name or 'Unknown'}\n"
        f"Confidence: {result.confidence}\n"
        f"Doc: {result.doc_url or 'Local markdown fallback'}\n"
        f"Missing context: {', '.join(result.missing_context) if result.missing_context else 'None'}\n"
        f"Next action: Review the prep doc before the meeting."
    )


def notification_command(result: PrepResult, recipient: str) -> tuple[list[str] | None, str | None]:
    if not valid_lark_open_id(recipient):
        return None, "notification skipped: PREP_NOTIFY_USER_ID/authenticated user id must be a Lark open_id like ou_xxx"
    markdown = build_notification_markdown(result).strip()
    if not markdown:
        return None, "notification skipped: message content is empty"
    idempotency_key = f"prep-{re.sub(r'[^a-z0-9]+', '-', result.doc_title.lower())[:80]}"
    return (
        [
            "im",
            "+messages-send",
            "--as",
            "bot",
            "--user-id",
            recipient,
            "--markdown",
            markdown,
            "--idempotency-key",
            idempotency_key,
        ],
        None,
    )


def send_notification(result: PrepResult, context: PrepContext, args: argparse.Namespace, debug: bool = False) -> str:
    if args.dry_run or args.no_notify:
        return "notification skipped"
    recipient = os.getenv("PREP_NOTIFY_USER_ID")
    if not recipient:
        status = auth_status(debug=debug)
        recipient = (status or {}).get("userOpenId")
    if not recipient:
        return "notification skipped: no PREP_NOTIFY_USER_ID and no authenticated user id"
    cmd, warning = notification_command(result, recipient)
    if warning or cmd is None:
        return warning or "notification skipped: invalid payload"
    data = run_lark(cmd, debug=debug)
    if data.get("ok"):
        return "bot IM sent to configured/authenticated user"
    return "notification failed: " + format_lark_error(data, 1)


def process_single(prep_input: PrepInput, args: argparse.Namespace, *, event: dict[str, Any] | None = None) -> PrepResult:
    if prep_input.mode == "event-id" and event is None:
        event = fetch_event(prep_input.value or "", debug=args.debug)
    context = build_context(prep_input, event=event, debug=args.debug)
    render_json = context_to_renderer_json(context)
    markdown = render(render_json)
    title = doc_title(render_json)
    json_path, md_path = write_local_outputs(render_json, markdown, title)
    debug_log(args.debug, f"wrote local JSON: {json_path}")
    debug_log(args.debug, f"wrote local Markdown: {md_path}")

    existing = choose_existing_doc(context.prior_docs, context.customer.canonical_name)
    doc_url, action = create_or_update_doc(markdown_path=md_path, title=title, existing_doc=existing, args=args, debug=args.debug)
    result = PrepResult(title, doc_url, prep_input.mode, context.customer.canonical_name, context.customer.confidence, context.missing_context)
    notify_status = send_notification(result, context, args, debug=args.debug)
    if args.output_json:
        print(json.dumps({"normalized": render_json, "result": asdict(result), "action": action, "notification": notify_status}, indent=2))
    else:
        print_summary(result, action, notify_status, context)
    return result


def print_summary(result: PrepResult, action: str, notify_status: str, context: PrepContext) -> None:
    print("Meeting prep generated.")
    print()
    print(f"Customer: {result.customer_name or 'Unknown'}")
    print(f"Confidence: {result.confidence}")
    print(f"Mode: {result.mode}")
    print(f"Doc: {result.doc_url or 'Local markdown fallback'}")
    print(f"Doc action: {action}")
    print(f"Prior docs found: {len(context.prior_docs)}")
    print(f"Notification: {notify_status}")
    if result.missing_context:
        print("Missing context:")
        for item in result.missing_context:
            print(f"- {item}")
    print("Next action:")
    print("- Review the prep doc before the meeting.")


def process_window(prep_input: PrepInput, args: argparse.Namespace) -> list[PrepResult]:
    start, end, tz_name = parse_window(prep_input.window or "")
    debug_log(args.debug, f"window timezone: {tz_name}; start={start.isoformat()} end={end.isoformat()}")
    events = fetch_window_events(start, end, debug=args.debug)
    results: list[PrepResult] = []
    skipped: list[tuple[str, str]] = []
    for event in events:
        qualified, reason = classify_event(event)
        if not qualified:
            skipped.append((event.get("summary") or "Untitled", reason))
            continue
        child_input = PrepInput(mode="window", value=event.get("event_id"), window=prep_input.window)
        results.append(process_single(child_input, args, event=event))
    if not args.output_json:
        print()
        print("Window summary")
        print("| Event | Customer | Confidence | Doc |")
        print("| --- | --- | --- | --- |")
        for result in results:
            print(f"| {result.doc_title} | {result.customer_name or 'Unknown'} | {result.confidence} | {result.doc_url or 'local'} |")
        if skipped:
            print()
            print("Skipped events")
            for title, reason in skipped:
                print(f"- {title}: {reason}")
        if not results:
            print("No qualified customer meetings found.")
    return results


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    prep_input = prep_input_from_args(args)
    try:
        if prep_input.mode == "window":
            process_window(prep_input, args)
        else:
            process_single(prep_input, args)
        return 0
    except PrepError as exc:
        if args.output_json:
            print(json.dumps({"ok": False, "error": str(exc)}, indent=2))
        else:
            print(f"Prep run failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
