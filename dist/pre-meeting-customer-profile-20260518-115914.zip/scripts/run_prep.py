#!/usr/bin/env python3
"""Portable orchestration CLI for BytePlus pre-meeting prep.

This script runs with the current user's local Lark CLI authentication. It
keeps all optional integrations best-effort so the skill remains useful from a
fresh zip install and in dry-run mode.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import html
import time as time_module
from urllib.parse import parse_qs, quote_plus, unquote, urlparse
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

try:
    from render_prep_doc import render
except ImportError:  # pragma: no cover - defensive for unusual launch paths
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from render_prep_doc import render


REPO_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = REPO_ROOT / "outputs" / "prep"
DEFAULT_CALENDAR_ID = os.getenv("LARK_CALENDAR_ID", "primary")
DEFAULT_TIMEZONE = os.getenv("DEFAULT_TIMEZONE", "Europe/London")
INTERNAL_DOMAINS = {
    item.strip().lower()
    for item in os.getenv(
        "INTERNAL_EMAIL_DOMAINS",
        "bytedance.com,byteplus.com,lark.com,larksuite.com,feishu.cn",
    ).split(",")
    if item.strip()
}
PERSONAL_EMAIL_DOMAINS = {
    "gmail.com",
    "googlemail.com",
    "yahoo.com",
    "outlook.com",
    "hotmail.com",
    "live.com",
    "icloud.com",
    "me.com",
    "proton.me",
    "protonmail.com",
    "qq.com",
    "163.com",
    "126.com",
}
INTERNAL_TITLE_PATTERNS = [
    "standup",
    "sync",
    "1:1",
    "one-on-one",
    "internal",
    "weekly",
    "daily",
    "retro",
    "retrospective",
    "planning",
    "team meeting",
    "all hands",
    "review",
    "catch up",
]


@dataclass
class PrepInput:
    mode: str
    value: str | None
    window: str | None


@dataclass
class CustomerIdentity:
    canonical_name: str | None
    domain: str | None
    email: str | None
    confidence: str
    evidence: list[str]


@dataclass
class PrepContext:
    customer: CustomerIdentity
    event: dict[str, Any] | None
    prior_docs: list[dict[str, Any]]
    enrichment: dict[str, Any] | None
    missing_context: list[str]
    search_results: list[dict[str, Any]] = field(default_factory=list)
    docs_search_available: bool = True
    web_search_available: bool = False
    known: dict[str, Any] = field(default_factory=dict)


@dataclass
class PrepResult:
    doc_title: str
    doc_url: str | None
    mode: str
    customer_name: str | None
    confidence: str
    missing_context: list[str]


class PrepError(RuntimeError):
    """User-facing orchestration error."""


def debug_log(enabled: bool, message: str) -> None:
    if enabled:
        print(f"[debug] {message}", file=sys.stderr)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--event-id")
    modes.add_argument("--customer")
    modes.add_argument("--domain")
    modes.add_argument("--email")
    modes.add_argument("--window")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--output-json", action="store_true")
    parser.add_argument("--create-doc", action="store_true", help="Explicitly allow new doc creation; this is the default outside dry-run.")
    parser.add_argument("--update-existing", action="store_true")
    parser.add_argument("--no-notify", action="store_true")
    parser.add_argument("--debug", action="store_true")
    return parser.parse_args(argv)


def prep_input_from_args(args: argparse.Namespace) -> PrepInput:
    for mode in ("event_id", "customer", "domain", "email", "window"):
        value = getattr(args, mode)
        if value:
            return PrepInput(mode=mode.replace("_", "-"), value=value, window=value if mode == "window" else None)
    raise PrepError("No input mode supplied.")


def require_lark_cli() -> str:
    path = shutil.which("lark-cli")
    if not path:
        raise PrepError(
            "lark-cli is not installed or is not on PATH. Install/configure Lark CLI, "
            "then run `lark-cli auth login` with the required scopes."
        )
    return path


def run_lark(args: list[str], *, debug: bool = False, check: bool = False) -> dict[str, Any]:
    require_lark_cli()
    cmd = ["lark-cli", *args]
    debug_log(debug, "running: " + " ".join(safe_arg(a) for a in cmd))
    proc = subprocess.run(cmd, text=True, capture_output=True, check=False)
    output = proc.stdout.strip() or proc.stderr.strip()
    try:
        data = json.loads(output) if output else {}
    except json.JSONDecodeError:
        data = {"ok": proc.returncode == 0, "raw": output}
    if check and proc.returncode != 0:
        raise PrepError(format_lark_error(data, proc.returncode))
    if proc.returncode != 0 and "ok" not in data:
        data["ok"] = False
    return data


def safe_arg(arg: str) -> str:
    if "TOKEN" in arg.upper() or "SECRET" in arg.upper():
        return "<redacted>"
    return arg


def format_lark_error(data: dict[str, Any], returncode: int) -> str:
    err = data.get("error") or {}
    msg = err.get("message") or data.get("message") or data.get("raw") or f"lark-cli failed with exit {returncode}"
    hint = err.get("hint")
    if hint:
        return f"{msg}\nNext: {hint}"
    return str(msg)


def infer_missing_scope(message: str) -> str | None:
    lowered = message.lower()
    scope_map = [
        ("calendar", "calendar:calendar.event:read"),
        ("docx", "docx:document:create or docx:document:write_only"),
        ("document", "docx:document:create or docx:document:write_only"),
        ("docs", "search:docs:read or docx document scopes"),
        ("search", "search:docs:read"),
        ("im", "im:message"),
        ("message", "im:message"),
        ("permission", "permission/scope not specific in Lark response"),
        ("scope", "scope not specific in Lark response"),
    ]
    for needle, scope in scope_map:
        if needle in lowered:
            return scope
    return None


def mask_token(token: str | None) -> str:
    if not token:
        return "none"
    if len(token) <= 8:
        return "<configured>"
    return f"{token[:4]}...{token[-4:]}"


def auth_status(debug: bool = False) -> dict[str, Any] | None:
    try:
        data = run_lark(["auth", "status"], debug=debug)
    except PrepError:
        return None
    if data.get("tokenStatus") == "valid":
        return data
    return None


def parse_email(value: str) -> tuple[str, str] | None:
    match = re.match(r"^[^@\s]+@([^@\s]+\.[^@\s]+)$", value.strip().lower())
    if not match:
        return None
    return value.strip().lower(), match.group(1)


def is_personal_domain(domain: str | None) -> bool:
    return bool(domain and domain.lower() in PERSONAL_EMAIL_DOMAINS)


def is_internal_domain(domain: str | None) -> bool:
    return bool(domain and domain.lower() in INTERNAL_DOMAINS)


def domain_to_name(domain: str | None) -> str | None:
    if not domain:
        return None
    root = domain.split(".")[0].replace("-", " ").replace("_", " ").strip()
    return root.title() if root else None


def normalize_domain(value: str | None) -> str | None:
    if not value:
        return None
    cleaned = value.strip().lower()
    cleaned = re.sub(r"^https?://", "", cleaned)
    cleaned = cleaned.split("/")[0]
    cleaned = cleaned[4:] if cleaned.startswith("www.") else cleaned
    return cleaned or None


def external_attendee_domains(event: dict[str, Any] | None) -> list[tuple[str, str]]:
    if not event:
        return []
    domains: list[tuple[str, str]] = []
    for attendee in event.get("attendees") or []:
        email = attendee.get("third_party_email") or attendee.get("email") or ""
        parsed = parse_email(email)
        if not parsed:
            continue
        _, domain = parsed
        if not is_internal_domain(domain) and not is_personal_domain(domain):
            domains.append((email, domain))
    return domains


def title_customer_candidate(title: str) -> str | None:
    cleaned = title.strip()
    patterns = [
        r"^(?:byteplus|bytedance|byte)\s*<>\s*(.+?)(?:\s+(?:sync|intro|discovery|call))?$",
        r"^(.+?)\s*<>\s*(?:byteplus|bytedance|byte)(?:\s+.*)?$",
        r"^customer call:\s*(.+?)\s*(?:x|&|and|<>|/)\s*(?:byteplus|bytedance|byte).*$",
        r"^(.+?)\s*(?:x|&|and|/)\s*(?:byteplus|bytedance|byte)(?:\s+.*)?$",
    ]
    for pattern in patterns:
        match = re.match(pattern, cleaned, re.IGNORECASE)
        if match:
            return cleanup_customer_name(match.group(1))
    return None


def cleanup_customer_name(value: str | None) -> str | None:
    if not value:
        return None
    cleaned = re.sub(r"\b(sync|intro|discovery|call|meeting)\b", "", value, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" -:|/")
    return cleaned or None


def resolve_customer(
    *,
    explicit_customer: str | None = None,
    explicit_domain: str | None = None,
    explicit_email: str | None = None,
    event: dict[str, Any] | None = None,
) -> CustomerIdentity:
    evidence: list[str] = []
    email: str | None = None
    domain = normalize_domain(explicit_domain)
    name = cleanup_customer_name(explicit_customer)
    confidence = "unknown"

    if name:
        evidence.append(f"explicit customer input: {name}")
        confidence = "confirmed"
    if domain:
        evidence.append(f"explicit domain input: {domain}")
        confidence = "confirmed"
        name = name or domain_to_name(domain)

    if explicit_email:
        parsed = parse_email(explicit_email)
        if parsed:
            email, email_domain = parsed
            evidence.append(f"explicit email input: {email}")
            if is_personal_domain(email_domain):
                evidence.append(f"personal email domain ignored for company inference: {email_domain}")
            else:
                domain = domain or email_domain
                name = name or domain_to_name(email_domain)
                evidence.append(f"corporate email domain: {email_domain}")
                confidence = "confirmed"

    for attendee_email, attendee_domain in external_attendee_domains(event):
        domain = domain or attendee_domain
        name = name or domain_to_name(attendee_domain)
        evidence.append(f"attendee email domain: {attendee_domain} ({attendee_email})")
        confidence = "confirmed"
        break

    if event and not name:
        candidate = title_customer_candidate(event.get("summary") or event.get("title") or "")
        if candidate:
            name = candidate
            evidence.append(f"title customer candidate: {candidate}")
            confidence = "likely" if confidence == "unknown" else confidence

    if name and confidence == "unknown":
        confidence = "likely"
    return CustomerIdentity(name, domain, email, confidence, evidence)


def parse_window(value: str, tz_name: str = DEFAULT_TIMEZONE, now: datetime | None = None) -> tuple[datetime, datetime, str]:
    tz = ZoneInfo(tz_name)
    current = now.astimezone(tz) if now else datetime.now(tz)
    today = current.date()
    if value == "today":
        start_day = today
        end_day = today + timedelta(days=1)
    elif value == "tomorrow":
        start_day = today + timedelta(days=1)
        end_day = today + timedelta(days=2)
    elif value == "next-7-days":
        start = current
        end = current + timedelta(days=7)
        return start, end, tz_name
    elif re.match(r"^past-\d+-hours$", value):
        hours = int(value.removeprefix("past-").removesuffix("-hours"))
        if hours <= 0:
            raise PrepError("Past-hour windows must be greater than zero.")
        start = current - timedelta(hours=hours)
        return start, current, tz_name
    elif re.match(r"^\d{4}-\d{2}-\d{2}:\d{4}-\d{2}-\d{2}$", value):
        raw_start, raw_end = value.split(":", 1)
        start_day = date.fromisoformat(raw_start)
        end_day = date.fromisoformat(raw_end)
    else:
        raise PrepError("Unsupported --window value. Use today, tomorrow, next-7-days, past-N-hours, or YYYY-MM-DD:YYYY-MM-DD.")
    return datetime.combine(start_day, time.min, tz), datetime.combine(end_day, time.min, tz), tz_name


def lark_time_to_iso(value: dict[str, Any] | None, fallback_tz: str = DEFAULT_TIMEZONE) -> str:
    if not value:
        return ""
    if value.get("timestamp"):
        tz = ZoneInfo(value.get("timezone") or fallback_tz)
        return datetime.fromtimestamp(int(value["timestamp"]), tz).isoformat()
    if value.get("date"):
        return value["date"]
    return ""


def fetch_event(event_id: str, debug: bool = False) -> dict[str, Any] | None:
    params = {
        "calendar_id": DEFAULT_CALENDAR_ID,
        "event_id": event_id,
        "need_attendee": True,
        "max_attendee_num": 50,
    }
    data = run_lark(
        ["calendar", "events", "get", "--params", json.dumps(params), "--as", "user", "--format", "json"],
        debug=debug,
    )
    if data.get("code") == 0:
        return data.get("data", {}).get("event")
    raise PrepError("Could not fetch Lark event. " + format_lark_error(data, 1))


def fetch_window_events(start: datetime, end: datetime, debug: bool = False) -> list[dict[str, Any]]:
    params = {
        "calendar_id": DEFAULT_CALENDAR_ID,
        "start_time": str(int(start.timestamp())),
        "end_time": str(int(end.timestamp())),
    }
    data = run_lark(
        ["calendar", "events", "instance_view", "--params", json.dumps(params), "--page-all", "--format", "json"],
        debug=debug,
    )
    if data.get("code") == 0:
        return data.get("data", {}).get("items") or []
    raise PrepError("Could not fetch Lark calendar window. " + format_lark_error(data, 1))


def search_docs(queries: list[str], debug: bool = False) -> tuple[list[dict[str, Any]], str | None]:
    docs: list[dict[str, Any]] = []
    seen: set[str] = set()
    attempted = 0
    failed = 0
    for query in [q for q in queries if q]:
        attempted += 1
        data = run_lark(["docs", "+search", "--query", query, "--format", "json"], debug=debug)
        if data.get("ok") is False and "too many request" in format_lark_error(data, 1).lower():
            debug_log(debug, f"docs search rate limited for {query!r}; retrying once")
            time_module.sleep(1.5)
            data = run_lark(["docs", "+search", "--query", query, "--format", "json"], debug=debug)
        if data.get("ok") is False or data.get("code") not in (0, None):
            failed += 1
            debug_log(debug, f"docs search failed for {query!r}: {format_lark_error(data, 1)}")
            continue
        items = data.get("data", {}).get("items") or data.get("data", {}).get("results") or data.get("items") or data.get("results") or []
        for item in items:
            normalized = normalize_doc_result(item)
            token = str(normalized.get("token") or normalized.get("url") or normalized.get("title"))
            if token and token not in seen:
                seen.add(token)
                docs.append(normalized)
    if failed and failed == attempted:
        return [], "Docs search unavailable due to permission or missing scope. Continuing without prior docs."
    if failed:
        return docs[:10], "Docs search partially unavailable; some queries failed, but usable prior docs were found."
    return docs[:10], None


def strip_markup(value: str | None) -> str:
    if not value:
        return ""
    text = re.sub(r"<[^>]+>", "", value)
    return html.unescape(text).strip()


def normalize_doc_result(item: dict[str, Any]) -> dict[str, Any]:
    meta = item.get("result_meta") or {}
    title = strip_markup(item.get("title_highlighted")) or item.get("title") or item.get("name") or item.get("docs_title") or "Untitled"
    summary = strip_markup(item.get("summary_highlighted") or item.get("summary"))
    url = meta.get("url") or item.get("url") or item.get("docs_url") or item.get("app_link") or ""
    date_value = meta.get("update_time_iso") or meta.get("create_time_iso") or item.get("create_time") or item.get("update_time") or ""
    return {
        "title": title,
        "url": url,
        "date": date_value,
        "summary": summary,
        "token": meta.get("token") or item.get("token") or item.get("doc_id") or url,
        "type": item.get("entity_type") or meta.get("doc_types") or item.get("type") or "",
    }


def relevance_score(text: str, terms: list[str]) -> int:
    lowered = text.lower()
    score = 0
    for term in [t.lower() for t in terms if t]:
        if term in lowered:
            score += 8 if " " in term else 3
        for part in term.split():
            if len(part) >= 4 and part.lower() in lowered:
                score += 1
    high_signal = [
        "founder",
        "ceo",
        "cto",
        "customer profile",
        "meeting notes",
        "ai notes",
        "prep",
        "poc",
        "opportunity",
        "seedance",
        "seedream",
        "ark",
        "maas",
        "lead",
        "pipeline",
    ]
    score += sum(2 for item in high_signal if item in lowered)
    low_signal = ["paper", "论文", "keyword highlighter", "guestlist", "newsletter", "standup"]
    score -= sum(4 for item in low_signal if item in lowered)
    return score


def rank_docs(docs: list[dict[str, Any]], terms: list[str], *, keep_existing_prep: bool = True, min_score: int = 8) -> list[dict[str, Any]]:
    ranked = []
    for doc in docs:
        text = " ".join(str(doc.get(key, "")) for key in ("title", "summary", "url"))
        score = relevance_score(text, terms)
        title = (doc.get("title") or "").lower()
        if keep_existing_prep and ("pre-meeting prep" in title or "customer profile" in title):
            score += 8
        if score >= min_score:
            enriched = dict(doc)
            enriched["relevance_score"] = score
            ranked.append(enriched)
    return sorted(ranked, key=lambda d: (d.get("relevance_score", 0), d.get("date", "")), reverse=True)


def infer_company_from_docs(customer_name: str | None, docs: list[dict[str, Any]]) -> str | None:
    if not customer_name:
        return None
    escaped = re.escape(customer_name)
    patterns = [
        rf"{escaped}\s+(?:Founder\s*&\s*CEO|Founder and CEO|CEO|Founder),\s*([A-Z][A-Za-z0-9 .&-]{{1,60}})",
        rf"{escaped}.*?\b(?:at|@)\s+([A-Z][A-Za-z0-9 .&-]{{1,60}})",
        rf"{escaped}.*?\|\s*([A-Z][A-Za-z0-9 .&-]{{1,60}})",
        rf"{escaped}\s+(?:AI Creative Technologist|Creative Technologist|Founder|CEO|CTO|CMO|Product Manager|Head of [A-Za-z ]+)\s+([A-Z][A-Za-z0-9 .&-]{{2,60}}?)\s+(?:video production|creative agencies|agency|studio|company|Country\b|[0-9]{{2,}})",
    ]
    for doc in docs:
        text = " ".join(str(doc.get(key, "")) for key in ("title", "summary"))
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                candidate = match.group(1).strip(" .;,-")
                candidate = re.split(r"\s{2,}|\s+Company\b|\s+creative agencies\b|\s+not on\b", candidate)[0].strip(" .;,-")
                words = candidate.split()
                if len(words) % 2 == 0 and words[: len(words) // 2] == words[len(words) // 2 :]:
                    candidate = " ".join(words[: len(words) // 2])
                if candidate and candidate.lower() not in customer_name.lower():
                    return candidate
    return None


def expand_internal_queries(identity: CustomerIdentity, company_name: str | None = None) -> list[str]:
    anchor = company_name or identity.canonical_name
    queries = [
        identity.canonical_name,
        identity.domain,
        f"{identity.canonical_name} {company_name}" if identity.canonical_name and company_name else None,
        f"{anchor} BytePlus" if anchor else None,
        f"{anchor} meeting notes" if anchor else None,
        f"{anchor} AI notes" if anchor else None,
        f"{anchor} customer profile" if anchor else None,
        f"{anchor} prep" if anchor else None,
        f"{anchor} Seedance" if anchor else None,
        f"{anchor} Seedream" if anchor else None,
        f"{anchor} Ark" if anchor else None,
        f"{anchor} MaaS" if anchor else None,
        f"{anchor} opportunity" if anchor else None,
        f"{anchor} POC" if anchor else None,
        f"{anchor} pricing" if anchor else None,
    ]
    deduped: list[str] = []
    seen: set[str] = set()
    for query in [q for q in queries if q]:
        normalized = query.lower()
        if normalized not in seen:
            seen.add(normalized)
            deduped.append(query)
    return deduped


def merge_docs(*groups: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: list[dict[str, Any]] = []
    seen: set[str] = set()
    for group in groups:
        for doc in group:
            key = str(doc.get("token") or doc.get("url") or doc.get("title"))
            if key and key not in seen:
                seen.add(key)
                merged.append(doc)
    return merged


def is_web_search_disabled() -> bool:
    return os.getenv("PREP_WEB_SEARCH_DISABLED", "").strip().lower() in {"1", "true", "yes", "on"}


def clean_duckduckgo_url(url: str) -> str:
    parsed = urlparse(html.unescape(url))
    if parsed.netloc.endswith("duckduckgo.com") and parsed.path.startswith("/l/"):
        target = parse_qs(parsed.query).get("uddg", [""])[0]
        return unquote(target) if target else url
    return html.unescape(url)


def web_search(query: str, *, max_results: int = 5, debug: bool = False) -> tuple[list[dict[str, str]], str | None]:
    if is_web_search_disabled():
        return [], "Web search disabled by PREP_WEB_SEARCH_DISABLED."
    url = f"https://duckduckgo.com/html/?q={quote_plus(query)}"
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            body = response.read().decode("utf-8", errors="replace")
    except (urllib.error.URLError, TimeoutError) as exc:
        debug_log(debug, f"web search failed for {query!r}: {exc}")
        return [], "Web search unavailable in this run."

    results: list[dict[str, str]] = []
    pattern = re.compile(
        r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>.*?(?:<a[^>]+class="result__snippet"[^>]*>(.*?)</a>|<div[^>]+class="result__snippet"[^>]*>(.*?)</div>)',
        re.IGNORECASE | re.DOTALL,
    )
    for match in pattern.finditer(body):
        link, raw_title, snippet_a, snippet_div = match.groups()
        title = strip_markup(raw_title)
        snippet = strip_markup(snippet_a or snippet_div)
        cleaned_url = clean_duckduckgo_url(link)
        if title and cleaned_url:
            results.append({"title": title, "url": cleaned_url, "snippet": snippet, "source": "web"})
        if len(results) >= max_results:
            break
    if not results:
        return [], "Web search returned no usable results."
    return results, None


def expand_web_queries(customer: CustomerIdentity, company_name: str | None) -> list[str]:
    anchor = company_name or customer.domain or customer.canonical_name
    if not anchor:
        return []
    queries = [
        f"{customer.canonical_name} {company_name}" if customer.canonical_name and company_name else None,
        f"{customer.canonical_name} {company_name} AI Video Lead" if customer.canonical_name and company_name else None,
        f"{anchor} company product",
        f"{anchor} official website",
        f"{anchor} Lavinia AI",
        f"{anchor} AI creative suite product",
        f"{anchor} founder {customer.canonical_name}" if customer.canonical_name and company_name else None,
        f"{anchor} users downloads funding revenue",
        f"{anchor} AI image generator video generator",
        f"{anchor} alternatives competitors",
        f"{anchor} pricing API enterprise",
        f"site:{customer.domain} {anchor} API" if customer.domain else None,
        f"site:{customer.domain} {anchor} video" if customer.domain else None,
    ]
    deduped: list[str] = []
    seen: set[str] = set()
    for query in [q for q in queries if q]:
        normalized = query.lower()
        if normalized not in seen:
            seen.add(normalized)
            deduped.append(query)
    return deduped


def collect_web_results(queries: list[str], debug: bool = False) -> tuple[list[dict[str, str]], str | None]:
    collected: list[dict[str, str]] = []
    seen: set[str] = set()
    warnings: list[str] = []
    for query in queries[:10]:
        results, warning = web_search(query, max_results=4, debug=debug)
        if warning:
            warnings.append(warning)
        for result in results:
            key = result.get("url") or result.get("title")
            if key and key not in seen:
                seen.add(key)
                enriched = dict(result)
                enriched["query"] = query
                collected.append(enriched)
    if collected:
        return sorted(collected, key=web_relevance_score, reverse=True)[:12], None
    return [], warnings[0] if warnings else "Web search returned no usable results."


def contextual_web_score(result: dict[str, str], customer_name: str | None, company_name: str | None) -> int:
    text = " ".join(str(result.get(key, "")) for key in ("title", "snippet", "url", "query")).lower()
    score = web_relevance_score(result)
    if company_name and company_name.lower() in text:
        score += 8
    elif company_name:
        score -= 12
    if customer_name and customer_name.lower() in text:
        score += 12
    if company_name and customer_name and company_name.lower() in text and customer_name.lower() in text:
        score += 12
    misleading_hosts = ("imagine.art", "gorokacoffee.com", "unigoroka.ac.pg", "papuanewguinea.travel", "pngyp.com", "business-yellowpages.com")
    host = urlparse(result.get("url", "")).netloc.lower()
    if any(item in host for item in misleading_hosts) and not (customer_name and customer_name.lower() in text):
        score -= 20
    return score


def web_relevance_score(result: dict[str, str]) -> int:
    text = " ".join(str(result.get(key, "")) for key in ("title", "snippet", "url", "query")).lower()
    score = 0
    for signal in ["official", "company product", "founder", "ceo", "users", "downloads", "funding", "revenue", "api", "pricing", "enterprise", "competitors"]:
        if signal in text:
            score += 3
    for signal in ["active users", "downloads", "bootstrapped", "api", "enterprise", "competitors", "openai", "runway", "luma"]:
        if signal in text:
            score += 4
    host = urlparse(result.get("url", "")).netloc.lower()
    if host.endswith("imagine.art") or host.endswith("imagineart.ai"):
        score += 8
    if any(blocked in host for blocked in ("bestreview", "greenrecord", "trustpilot")):
        score -= 3
    return score


def likely_official_web_result(result: dict[str, str], company_name: str | None) -> bool:
    if not company_name:
        return False
    host = urlparse(result.get("url", "")).netloc.lower().removeprefix("www.")
    compact_company = re.sub(r"[^a-z0-9]+", "", company_name.lower())
    compact_host = re.sub(r"[^a-z0-9]+", "", host.split(":")[0])
    blocked = ("linkedin.com", "crunchbase.com", "producthunt.com", "trustpilot.com", "youtube.com", "gadinsider.com", "usatoday.com", "compworth.com", "growjo.com", "pitchbook.com", "gorokacoffee.com")
    return compact_company in compact_host and not any(item in host for item in blocked)


def blocked_as_company_website(host: str) -> bool:
    blocked = (
        "linkedin.com",
        "google.com",
        "facebook.com",
        "x.com",
        "twitter.com",
        "rocketreach.co",
        "checkcompany.co.uk",
        "company-information.service.gov.uk",
        "crunchbase.com",
        "producthunt.com",
        "trustpilot.com",
        "youtube.com",
        "gadinsider.com",
        "usatoday.com",
        "everybodywiki.com",
        "greenrecord.co.uk",
        "bestreviewinsight.com",
        "purpleaitools.com",
        "compworth.com",
        "growjo.com",
        "pitchbook.com",
        "gorokacoffee.com",
        "unigoroka.ac.pg",
        "papuanewguinea.travel",
        "pngyp.com",
        "business-yellowpages.com",
    )
    return any(item in host for item in blocked)


def product_description_score(result: dict[str, str]) -> int:
    text = " ".join(str(result.get(key, "")) for key in ("title", "snippet", "url")).lower()
    score = 0
    for signal in ["ai creative suite", "generates images", "videos", "voice", "prompt", "editing tools", "custom models"]:
        if signal in text:
            score += 3
    for low_signal in ["pricing", "faq", "frequently asked", "review", "trustpilot", "crunchbase", "competitors", "monetization", "help center", "community", "compworth", "growjo", "pitchbook"]:
        if low_signal in text:
            score -= 4
    if likely_official_web_result(result, None):
        score += 2
    return score


def stable_company_website(host: str) -> str:
    normalized = host.lower().removeprefix("www.")
    for prefix in ("docs.", "help.", "support.", "community."):
        if normalized.startswith(prefix):
            return normalized.removeprefix(prefix)
    return normalized


def stable_company_description(company_name: str | None, description: str, use_cases: list[str]) -> str:
    lowered = description.lower()
    weak_page = any(item in lowered for item in ("monetization", "help center", "community", "pricing", "frequently asked"))
    if company_name and (weak_page or not description):
        if use_cases:
            return f"{company_name} appears to be a generative AI creative platform focused on " + ", ".join(use_cases[:3]) + "."
        return f"{company_name} appears to be a generative AI creative platform; validate product scope in the meeting."
    return description


def source_tier(url: str, company_name: str | None = None) -> tuple[int, str]:
    host = urlparse(url).netloc.lower().removeprefix("www.")
    if host.startswith(("docs.", "help.", "support.")):
        return 1, "Tier 1 - official docs/help"
    if company_name and likely_official_web_result({"url": url}, company_name):
        return 1, "Tier 1 - official company site"
    if any(item in host for item in ("larkoffice.com", "feishu.cn")):
        return 2, "Tier 2 - internal Lark source"
    if any(item in host for item in ("crunchbase.com", "producthunt.com", "linkedin.com")):
        return 3, "Tier 3 - business directory/social profile"
    return 4, "Tier 4 - public web/news/review"


def fetch_page_text(url: str, debug: bool = False) -> tuple[str, str | None]:
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            content_type = response.headers.get("content-type", "")
            if "text/html" not in content_type and "text/plain" not in content_type:
                return "", f"unsupported content type: {content_type}"
            html_body = response.read(400_000).decode("utf-8", errors="replace")
    except (urllib.error.URLError, TimeoutError) as exc:
        debug_log(debug, f"page fetch failed for {url}: {exc}")
        return "", "page fetch failed"
    text = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", html_body)
    text = re.sub(r"(?is)<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:20000], None


def collect_page_evidence(results: list[dict[str, str]], company_name: str | None, debug: bool = False) -> list[dict[str, Any]]:
    pages: list[dict[str, Any]] = []
    selected: list[dict[str, str]] = []
    official = [item for item in results if likely_official_web_result(item, company_name)]
    selected.extend(official[:2])
    for item in results:
        url = item.get("url", "")
        if any(signal in url.lower() for signal in ("pricing", "docs.", "help.", "producthunt", "crunchbase")):
            selected.append(item)
        if len(selected) >= 6:
            break
    seen: set[str] = set()
    for item in selected[:6]:
        url = item.get("url", "")
        if not url or url in seen:
            continue
        seen.add(url)
        text, warning = fetch_page_text(url, debug=debug)
        tier, tier_label = source_tier(url, company_name)
        pages.append(
            {
                "title": item.get("title", ""),
                "url": url,
                "snippet": item.get("snippet", ""),
                "text": text,
                "fetch_warning": warning or "",
                "tier": tier,
                "tier_label": tier_label,
                "source": "web_page",
            }
        )
    return pages


def extract_pricing_tiers(text: str) -> list[str]:
    tiers = []
    for tier in ["Free", "Basic", "Standard", "Ultimate", "Creator", "Enterprise", "Pro", "Team", "Business"]:
        if re.search(rf"\b{re.escape(tier)}\b", text, re.IGNORECASE):
            tiers.append(tier)
    return tiers[:8]


def extract_company_dossier(
    company_name: str | None,
    enrichment_description: str,
    use_cases: list[str],
    web_results: list[dict[str, str]],
    pages: list[dict[str, Any]],
) -> dict[str, Any]:
    combined = " ".join(
        [enrichment_description]
        + [f"{item.get('title', '')} {item.get('snippet', '')}" for item in web_results]
        + [page.get("text", "") for page in pages]
    )
    modules = []
    module_signals = [
        ("AI image generation", ("image", "text-to-image", "ai art")),
        ("AI video generation", ("video", "text-to-video", "shorts")),
        ("Voice/audio generation", ("voice", "audio", "music")),
        ("Background remover", ("background remover", "bg remover")),
        ("Upscaler", ("upscaler", "upscale")),
        ("Custom models", ("custom model", "custom models")),
        ("API / enterprise plans", ("api", "enterprise")),
    ]
    lowered = combined.lower()
    for label, needles in module_signals:
        if any(needle in lowered for needle in needles):
            modules.append(label)

    pricing_tiers = extract_pricing_tiers(combined)
    scale_signals = []
    for pattern in [
        r"over\s+[\d.]+\s*(?:million|m|k)\s+active users",
        r"[\d.]+\s*(?:million|m|k)\s+downloads",
        r"used by millions",
        r"millions worldwide",
    ]:
        for match in re.finditer(pattern, combined, re.IGNORECASE):
            signal = match.group(0)
            if signal not in scale_signals:
                scale_signals.append(signal)

    founders = []
    for pattern in [r"founder(?: and CEO)?\s+([A-Z][A-Za-z .'-]{2,60})", r"led by\s+([A-Z][A-Za-z .'-]{2,60})"]:
        for match in re.finditer(pattern, combined):
            value = match.group(1).strip(" .")
            if value and value not in founders:
                founders.append(value)

    hq = ""
    hq_match = re.search(r"located in\s+([A-Z][A-Za-z ,.-]{2,80})", combined)
    if hq_match:
        hq = re.split(r"\bWho\b|\bWhat\b|\bWhen\b|\bFrequently\b", hq_match.group(1))[0].strip(" .")

    source_evidence = []
    for item in sorted(web_results[:8], key=lambda x: source_tier(x.get("url", ""), company_name)[0]):
        tier, tier_label = source_tier(item.get("url", ""), company_name)
        source_evidence.append(
            {
                "claim": item.get("snippet") or item.get("title") or item.get("url"),
                "url": item.get("url", ""),
                "tier": tier,
                "tier_label": tier_label,
            }
        )

    return {
        "company": company_name or "",
        "what_they_do": stable_company_description(company_name, enrichment_description, use_cases),
        "product_modules": modules,
        "pricing_tiers": pricing_tiers,
        "scale_signals": scale_signals[:5],
        "founders_or_leadership": founders[:5],
        "hq": hq,
        "source_evidence": source_evidence[:8],
        "not_found": [
            item
            for item, present in [
                ("Funding", "funding" in lowered or "bootstrapped" in lowered),
                ("Current model vendors", any(vendor in lowered for vendor in ("openai", "runway", "luma", "midjourney"))),
                ("Enterprise customer count", "enterprise customer" in lowered),
                ("API volume / monthly generation volume", bool(scale_signals)),
            ]
            if not present
        ],
    }


def infer_use_cases(text: str) -> list[str]:
    lowered = text.lower()
    use_cases: list[str] = []
    signals = [
        (("image", "ai art", "text-to-image", "background remover", "upscaler"), "image generation and creative asset editing"),
        (("video", "shorts", "text-to-video", "ai video"), "video generation / short-form creative workflow"),
        (("voice", "audio", "tts", "text to speech"), "voice or audio generation workflow"),
        (("api", "enterprise", "custom model"), "API or enterprise integration requirements"),
    ]
    for needles, label in signals:
        if any(needle in lowered for needle in needles) and label not in use_cases:
            use_cases.append(label)
    return use_cases


def infer_competitors(text: str) -> list[str]:
    competitors = []
    for name in ["OpenAI", "Runway", "Midjourney", "Stability AI", "Adobe Firefly", "Pika", "Kling", "Luma"]:
        if name.lower() in text.lower():
            competitors.append(f"{name} or adjacent creative AI tools")
    return competitors[:5]


def infer_metrics(text: str) -> dict[str, str]:
    metrics: dict[str, str] = {}
    active_users = re.search(r"over\s+([\d.]+\s*(?:million|m|k))\s+active users", text, re.IGNORECASE)
    downloads = re.search(r"([\d.]+\s*(?:million|m|k))\s+downloads", text, re.IGNORECASE)
    if active_users:
        metrics["paid_users"] = f"Likely scale signal: over {active_users.group(1)} active users (?)"
    if downloads:
        metrics["monthly_volume"] = f"Likely adoption signal: {downloads.group(1)} downloads mentioned publicly (?)"
    return metrics


def synthesize_known_fields(enrichment: dict[str, Any] | None, docs: list[dict[str, Any]], web_results: list[dict[str, str]]) -> dict[str, Any]:
    if not enrichment:
        return {}
    text = " ".join(
        [enrichment.get("description", "")]
        + [str(doc.get("summary", "")) for doc in docs[:5]]
        + [f"{item.get('title', '')} {item.get('snippet', '')}" for item in web_results[:8]]
    )
    known: dict[str, Any] = {}
    company = enrichment.get("company_name")
    if company:
        known["stakeholder_context"] = f"Likely: {company} stakeholder; validate role, buying authority, and meeting objective."
    if enrichment.get("description"):
        known["objectives"] = "To Validate: confirm whether the customer is evaluating model quality, API/inference scale, cost, or enterprise deployment."
        known["pain_points"] = "Likely: creative AI teams often care about output quality, controllability, latency, generation cost, and safety/commercial rights (?)"
    metrics = infer_metrics(text)
    known.update(metrics)
    if "api" in text.lower() or "enterprise" in text.lower():
        known["current_models"] = "To Validate: whether they use in-house models, open-source models, or third-party APIs for generation."
        known["current_vendors"] = "To Validate: current image/video generation providers and fallback stack."
    dossier = enrichment.get("dossier") or {}
    if dossier.get("scale_signals"):
        known["monthly_volume"] = "Public scale signal: " + "; ".join(dossier["scale_signals"][:2]) + " (?)"
        known["paid_users"] = "To Validate: paid/free split; public sources mention usage scale but not paid user count."
    if dossier.get("pricing_tiers"):
        known["budget_status"] = "Public pricing/packaging found: " + ", ".join(dossier["pricing_tiers"]) + ". Validate current AI infra spend."
    if dossier.get("product_modules"):
        known["expansion_opportunity"] = "Likely product modules: " + ", ".join(dossier["product_modules"][:6])
    return known


def build_web_enrichment(context: PrepContext, debug: bool = False) -> tuple[dict[str, Any] | None, list[dict[str, str]], str | None]:
    customer = context.customer
    inferred_company = infer_company_from_docs(customer.canonical_name, context.prior_docs)
    queries = expand_web_queries(customer, inferred_company)
    if not queries:
        return None, [], "Web search skipped because customer identity is unknown."
    results, warning = collect_web_results(queries, debug=debug)
    if not results:
        return None, [], warning
    scored_results = sorted(
        ((contextual_web_score(item, customer.canonical_name, inferred_company), item) for item in results),
        key=lambda pair: pair[0],
        reverse=True,
    )
    filtered_results = [item for score, item in scored_results if score > 0]
    results = (filtered_results or [item for _, item in scored_results])[:12]
    page_evidence = collect_page_evidence(results, inferred_company, debug=debug)

    source_links = [{"label": item["title"], "url": item["url"]} for item in results[:5]]
    preferred = results[0]
    for item in results:
        haystack = f"{item.get('title', '')} {item.get('snippet', '')}".lower()
        if customer.canonical_name and inferred_company and customer.canonical_name.lower() in haystack and inferred_company.lower() in haystack:
            preferred = item
            break
    else:
        preferred = max(results, key=product_description_score)
    for item in results:
        if likely_official_web_result(item, inferred_company):
            preferred = item
            break
    if inferred_company:
        for item in results:
            haystack = f"{item.get('title', '')} {item.get('snippet', '')}".lower()
            if inferred_company.lower() in haystack and preferred == results[0]:
                preferred = item
                break
    description = preferred.get("snippet") or ""
    website = customer.domain or ""
    if not website:
        for item in results:
            parsed = urlparse(item["url"])
            host = parsed.netloc.lower().removeprefix("www.")
            if host and likely_official_web_result(item, inferred_company) and not blocked_as_company_website(host):
                website = stable_company_website(host)
                break
    combined = " ".join((item.get("title", "") + " " + item.get("snippet", "")).lower() for item in results)
    use_cases = infer_use_cases(combined)
    if any(term in combined for term in ("creative", "generation", "artificial intelligence")) and not use_cases:
        use_cases.append("creative AI / generative media workflow")
    description = stable_company_description(inferred_company, description, use_cases)
    dossier = extract_company_dossier(inferred_company, description, use_cases, results, page_evidence)
    if dossier.get("what_they_do"):
        description = dossier["what_they_do"]
    competitors = infer_competitors(combined)
    enrichment = {
        "available": True,
        "confidence": "medium",
        "website": website,
        "company_name": inferred_company or "",
        "description": description,
        "dossier": dossier,
        "page_evidence": page_evidence,
        "industry": "To Validate: inferred from public web results",
        "known_use_cases": use_cases,
        "known_competitors": competitors,
        "known_risks": ["Public web context only; validate customer requirements, budget, timeline, and decision process"],
        "possible_byteplus_fit": [
            {"product": "Seedance", "reason": "Validate fit for video generation quality, consistency, and short-form creative workflows", "confidence": "medium"},
            {"product": "Seedream", "reason": "Validate fit for image generation, editing, upscaling, and creative asset production", "confidence": "medium"},
            {"product": "Ark / model platform", "reason": "Validate model evaluation, deployment, routing, cost/performance, and API-scale needs", "confidence": "medium"},
        ],
        "suggested_questions": [
            "Can you confirm whether this discussion is for the company/product identified in the prep?",
            "Are you evaluating BytePlus for model quality, API/inference scale, cost/performance, or enterprise deployment?",
            "Which image/video generation capabilities are most important: quality, controllability, consistency, speed, safety, or cost?",
            "What is your current generation stack, and which vendors/models are you benchmarking against?",
            "What monthly generation volume, peak concurrency, and latency targets should we size for?",
            "Would a POC be judged by creative quality, conversion lift, production cost, or developer integration effort?",
        ],
        "source_links": source_links,
        "source": "web_search",
    }
    return enrichment, results, None


def is_likely_prep_doc(doc: dict[str, Any], customer_name: str | None) -> bool:
    title = (doc.get("title") or "").lower()
    if customer_name and customer_name.lower() not in title:
        return False
    return "pre-meeting prep" in title or "customer profile" in title or "prep" in title


def choose_existing_doc(docs: list[dict[str, Any]], customer_name: str | None) -> dict[str, Any] | None:
    for doc in docs:
        if is_likely_prep_doc(doc, customer_name):
            return doc
    return None


def classify_event(event: dict[str, Any], explicit_identity: CustomerIdentity | None = None) -> tuple[bool, str]:
    title = (event.get("summary") or "").lower()
    has_external_domain = bool(external_attendee_domains(event))
    has_customer_signal = has_external_domain or bool(title_customer_candidate(event.get("summary") or ""))
    if explicit_identity and explicit_identity.canonical_name:
        lowered = explicit_identity.canonical_name.lower()
        has_customer_signal = has_customer_signal or lowered in title
    if any(pattern in title for pattern in INTERNAL_TITLE_PATTERNS) and not has_customer_signal:
        return False, "internal/generic title without customer signal"
    if has_customer_signal:
        return True, "customer signal found"
    return False, "no external corporate attendee or customer signal"


def call_mcp_enrichment(context: PrepContext, debug: bool = False) -> dict[str, Any] | None:
    url = os.getenv("MCP_CUSTOMER_ENRICHMENT_URL")
    token = os.getenv("MCP_CUSTOMER_ENRICHMENT_TOKEN")
    if not url:
        debug_log(debug, "MCP_CUSTOMER_ENRICHMENT_URL not configured; skipping enrichment")
        return None
    payload = {
        "customer_name": context.customer.canonical_name,
        "domain": context.customer.domain,
        "email": context.customer.email,
        "event": context.event or {},
        "prior_docs_summary": context.prior_docs[:5],
    }
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        debug_log(debug, f"MCP enrichment failed: {exc}")
        context.missing_context.append("MCP enrichment configured but request failed")
        return None


def build_context(
    prep_input: PrepInput,
    *,
    event: dict[str, Any] | None,
    debug: bool = False,
) -> PrepContext:
    explicit_customer = prep_input.value if prep_input.mode == "customer" else None
    explicit_domain = prep_input.value if prep_input.mode == "domain" else None
    explicit_email = prep_input.value if prep_input.mode == "email" else None
    identity = resolve_customer(
        explicit_customer=explicit_customer,
        explicit_domain=explicit_domain,
        explicit_email=explicit_email,
        event=event,
    )
    missing: list[str] = []
    if not event:
        missing.append("meeting context")
    if identity.confidence in {"weak", "unknown"}:
        missing.append("confirmed customer identity")

    search_terms = expand_internal_queries(identity)
    initial_docs, search_warning = search_docs(search_terms[:6], debug=debug)
    inferred_company = infer_company_from_docs(identity.canonical_name, initial_docs)
    expanded_docs: list[dict[str, Any]] = []
    expanded_warning: str | None = None
    if inferred_company:
        expanded_docs, expanded_warning = search_docs(expand_internal_queries(identity, inferred_company), debug=debug)
    prior_docs = rank_docs(merge_docs(initial_docs, expanded_docs), [identity.canonical_name or "", identity.domain or "", inferred_company or ""])[:10]
    if search_warning:
        missing.append(search_warning)
    if expanded_warning and expanded_warning != search_warning:
        missing.append(expanded_warning)

    context = PrepContext(identity, event, prior_docs, None, missing, docs_search_available=bool(prior_docs) or search_warning is None)
    mcp_enrichment = call_mcp_enrichment(context, debug=debug)
    web_enrichment, web_results, web_warning = build_web_enrichment(context, debug=debug)
    context.search_results = web_results
    context.web_search_available = bool(web_results)
    context.enrichment = mcp_enrichment or web_enrichment
    context.known = synthesize_known_fields(context.enrichment, context.prior_docs, context.search_results)
    if web_warning:
        context.missing_context.append(web_warning)
    if mcp_enrichment is None:
        context.missing_context.append("MCP enrichment unavailable")
    return context


def context_to_renderer_json(context: PrepContext) -> dict[str, Any]:
    event = context.event or {}
    customer = context.customer
    enrichment = normalize_enrichment(context.enrichment, context)
    attendees = []
    for attendee in event.get("attendees") or []:
        email = attendee.get("third_party_email") or attendee.get("email") or ""
        attendees.append(
            {
                "name": attendee.get("display_name") or email,
                "email": email,
                "external": bool(attendee.get("is_external") or attendee.get("type") == "third_party"),
            }
        )
    if customer.email and not attendees:
        attendees.append({"name": customer.email, "email": customer.email, "external": True})

    meeting = {
        "title": event.get("summary") or "Customer prep",
        "start": lark_time_to_iso(event.get("start_time")),
        "end": lark_time_to_iso(event.get("end_time")),
        "timezone": (event.get("start_time") or {}).get("timezone") or DEFAULT_TIMEZONE,
        "organizer": {"name": (event.get("event_organizer") or {}).get("display_name", ""), "email": ""},
        "sa": {"name": "", "email": ""},
        "url": event.get("app_link") or (event.get("vchat") or {}).get("meeting_url") or "",
    }
    return {
        "meeting": meeting,
        "customer": {
            "name": customer.canonical_name or "<unknown> (please confirm)",
            "domain": customer.domain or "",
            "website": enrichment.get("website", ""),
            "company_name": enrichment.get("company_name", ""),
            "industry": enrichment.get("industry", ""),
            "hq": enrichment.get("hq", ""),
            "company_size": enrichment.get("company_size", ""),
            "description": enrichment.get("description", ""),
            "confidence": "high" if customer.confidence == "confirmed" else customer.confidence,
        },
        "attendees": attendees,
        "enrichment": enrichment,
        "prior_docs": context.prior_docs,
        "prior_notes": [],
        "search_results": context.search_results,
        "known": context.known,
        "source_status": {
            "calendar": "available" if event else "missing",
            "attendees": "available" if attendees else "missing",
            "mcp": "available" if context.enrichment and context.enrichment.get("source") != "web_search" else "unavailable",
            "prior_docs": "available" if context.prior_docs else "none",
            "docs_search": "available" if context.docs_search_available else "unavailable",
            "web_search": "available" if context.web_search_available else "unavailable",
        },
    }


def normalize_enrichment(enrichment: dict[str, Any] | None, context: PrepContext) -> dict[str, Any]:
    if not enrichment:
        return {
            "available": False,
            "confidence": context.customer.confidence,
            "known_use_cases": ["To Validate: customer use case"],
            "known_competitors": [],
            "known_risks": ["Missing confirmed budget, decision maker, timeline, current vendor, and success metrics"],
            "possible_byteplus_fit": [
                {"product": "Seed / Doubao LLM", "reason": "Validate AI workload and model requirements", "confidence": "medium"},
                {"product": "Ark / model platform", "reason": "Validate model evaluation, deployment, and routing needs", "confidence": "medium"},
            ],
            "suggested_questions": [],
            "source_links": [],
        }
    return {
        "available": True,
        "confidence": enrichment.get("confidence") or context.customer.confidence,
        "known_use_cases": enrichment.get("known_use_cases") or enrichment.get("use_cases") or [],
        "known_competitors": enrichment.get("known_competitors") or enrichment.get("competitors") or [],
        "known_risks": enrichment.get("known_risks") or enrichment.get("risks") or [],
        "possible_byteplus_fit": enrichment.get("possible_byteplus_fit") or enrichment.get("recommended_products") or [],
        "suggested_questions": enrichment.get("suggested_questions") or enrichment.get("questions_to_ask") or [],
        "source_links": enrichment.get("source_links") or [],
        "source": enrichment.get("source", ""),
        "company_name": enrichment.get("company_name", ""),
        "dossier": enrichment.get("dossier") or {},
        "page_evidence": enrichment.get("page_evidence") or [],
        "website": enrichment.get("website", ""),
        "industry": enrichment.get("industry", ""),
        "hq": enrichment.get("hq", ""),
        "company_size": enrichment.get("company_size", ""),
        "description": enrichment.get("description", ""),
    }


def doc_title(render_json: dict[str, Any]) -> str:
    customer = render_json.get("customer", {}).get("name") or "<unknown> (please confirm)"
    start = render_json.get("meeting", {}).get("start")
    label = "TBD"
    if start:
        try:
            label = datetime.fromisoformat(start).strftime("%d-%m-%Y")
        except ValueError:
            pass
    return f"BytePlus <> {customer} - {label} - Pre-Meeting Prep"


def write_local_outputs(render_json: dict[str, Any], markdown: str, title: str) -> tuple[Path, Path]:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-") or "prep"
    json_path = OUTPUT_ROOT / f"{slug}.json"
    md_path = OUTPUT_ROOT / f"{slug}.md"
    json_path.write_text(json.dumps(render_json, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    md_path.write_text(markdown + "\n", encoding="utf-8")
    return json_path, md_path


def lark_markdown_arg(path: Path) -> str:
    try:
        relative = path.resolve().relative_to(Path.cwd().resolve())
        return f"@{relative.as_posix()}"
    except ValueError:
        return f"@{path}"


def create_or_update_doc(
    *,
    markdown_path: Path,
    title: str,
    existing_doc: dict[str, Any] | None,
    args: argparse.Namespace,
    debug: bool = False,
) -> tuple[str | None, str]:
    if args.dry_run:
        return None, "dry-run: no Lark write"
    fallback_written = markdown_path.exists() and markdown_path.stat().st_size > 0
    markdown_arg = lark_markdown_arg(markdown_path)
    if args.update_existing and existing_doc and existing_doc.get("url"):
        data = run_lark(
            [
                "docs",
                "+update",
                "--doc",
                existing_doc["url"],
                "--markdown",
                markdown_arg,
                "--mode",
                "overwrite",
                "--new-title",
                title,
                "--as",
                "user",
            ],
            debug=debug,
        )
        if data.get("ok"):
            return existing_doc.get("url"), "updated existing doc"
        message = format_lark_error(data, 1)
        status = auth_status(debug=debug)
        diagnostic = [
            "Could not update existing Lark doc; local markdown output created instead.",
            f"Lark CLI auth exists: {'yes' if status else 'no'}",
            f"Likely missing scope: {infer_missing_scope(message) or 'unknown'}",
            "Folder token attempted: none (existing document update)",
            f"Fallback markdown written successfully: {'yes' if fallback_written else 'no'}",
        ]
        return None, "\n".join(diagnostic)

    folder = os.getenv("PREP_DOC_FOLDER_TOKEN") or os.getenv("CUSTOMER_PROFILE_FOLDER_TOKEN")
    cmd = ["docs", "+create", "--title", title, "--markdown", markdown_arg, "--as", "user"]
    if folder:
        cmd[2:2] = ["--folder-token", folder]
    data = run_lark(cmd, debug=debug)
    if data.get("ok"):
        return data.get("data", {}).get("doc_url"), "created Lark doc"
    first_error = format_lark_error(data, 1)
    if folder:
        fallback = run_lark(["docs", "+create", "--title", title, "--markdown", markdown_arg, "--as", "user"], debug=debug)
        if fallback.get("ok"):
            return fallback.get("data", {}).get("doc_url"), "created Lark doc in default space after folder fallback"
        first_error = first_error + " | default-space fallback: " + format_lark_error(fallback, 1)
    status = auth_status(debug=debug)
    diagnostic = [
        "Could not create Lark doc due to missing permission or auth. Local markdown output created instead.",
        f"Lark CLI auth exists: {'yes' if status else 'no'}",
        f"Likely missing scope: {infer_missing_scope(first_error) or 'unknown'}",
        f"Folder token attempted: {mask_token(folder)}",
        f"Fallback markdown written successfully: {'yes' if fallback_written else 'no'}",
    ]
    return None, "\n".join(diagnostic)


def valid_lark_open_id(value: str | None) -> bool:
    return bool(value and re.match(r"^ou_[A-Za-z0-9_-]{8,}$", value))


def build_notification_markdown(result: PrepResult) -> str:
    return (
        f"Meeting prep generated.\n\n"
        f"Customer: {result.customer_name or 'Unknown'}\n"
        f"Confidence: {result.confidence}\n"
        f"Doc: {result.doc_url or 'Local markdown fallback'}\n"
        f"Missing context: {', '.join(result.missing_context) if result.missing_context else 'None'}\n"
        f"Next action: Review the prep doc before the meeting."
    )


def notification_command(result: PrepResult, recipient: str) -> tuple[list[str] | None, str | None]:
    if not valid_lark_open_id(recipient):
        return None, "notification skipped: PREP_NOTIFY_USER_ID/authenticated user id must be a Lark open_id like ou_xxx"
    markdown = build_notification_markdown(result).strip()
    if not markdown:
        return None, "notification skipped: message content is empty"
    idempotency_key = f"prep-{re.sub(r'[^a-z0-9]+', '-', result.doc_title.lower())[:80]}"
    return (
        [
            "im",
            "+messages-send",
            "--as",
            "bot",
            "--user-id",
            recipient,
            "--markdown",
            markdown,
            "--idempotency-key",
            idempotency_key,
        ],
        None,
    )


def send_notification(result: PrepResult, context: PrepContext, args: argparse.Namespace, debug: bool = False) -> str:
    if args.dry_run or args.no_notify:
        return "notification skipped"
    recipient = os.getenv("PREP_NOTIFY_USER_ID")
    if not recipient:
        status = auth_status(debug=debug)
        recipient = (status or {}).get("userOpenId")
    if not recipient:
        return "notification skipped: no PREP_NOTIFY_USER_ID and no authenticated user id"
    cmd, warning = notification_command(result, recipient)
    if warning or cmd is None:
        return warning or "notification skipped: invalid payload"
    data = run_lark(cmd, debug=debug)
    if data.get("ok"):
        return "bot IM sent to configured/authenticated user"
    return "notification failed: " + format_lark_error(data, 1)


def process_single(prep_input: PrepInput, args: argparse.Namespace, *, event: dict[str, Any] | None = None) -> PrepResult:
    if prep_input.mode == "event-id" and event is None:
        event = fetch_event(prep_input.value or "", debug=args.debug)
    context = build_context(prep_input, event=event, debug=args.debug)
    render_json = context_to_renderer_json(context)
    markdown = render(render_json)
    title = doc_title(render_json)
    json_path, md_path = write_local_outputs(render_json, markdown, title)
    debug_log(args.debug, f"wrote local JSON: {json_path}")
    debug_log(args.debug, f"wrote local Markdown: {md_path}")

    existing = choose_existing_doc(context.prior_docs, context.customer.canonical_name)
    doc_url, action = create_or_update_doc(markdown_path=md_path, title=title, existing_doc=existing, args=args, debug=args.debug)
    result = PrepResult(title, doc_url, prep_input.mode, context.customer.canonical_name, context.customer.confidence, context.missing_context)
    notify_status = send_notification(result, context, args, debug=args.debug)
    if args.output_json:
        print(json.dumps({"normalized": render_json, "result": asdict(result), "action": action, "notification": notify_status}, indent=2))
    else:
        print_summary(result, action, notify_status, context)
    return result


def print_summary(result: PrepResult, action: str, notify_status: str, context: PrepContext) -> None:
    print("Meeting prep generated.")
    print()
    print(f"Customer: {result.customer_name or 'Unknown'}")
    print(f"Confidence: {result.confidence}")
    print(f"Mode: {result.mode}")
    print(f"Doc: {result.doc_url or 'Local markdown fallback'}")
    print(f"Doc action: {action}")
    print(f"Prior docs found: {len(context.prior_docs)}")
    print(f"Notification: {notify_status}")
    if result.missing_context:
        print("Missing context:")
        for item in result.missing_context:
            print(f"- {item}")
    print("Next action:")
    print("- Review the prep doc before the meeting.")


def process_window(prep_input: PrepInput, args: argparse.Namespace) -> list[PrepResult]:
    start, end, tz_name = parse_window(prep_input.window or "")
    debug_log(args.debug, f"window timezone: {tz_name}; start={start.isoformat()} end={end.isoformat()}")
    events = fetch_window_events(start, end, debug=args.debug)
    results: list[PrepResult] = []
    skipped: list[tuple[str, str]] = []
    for event in events:
        qualified, reason = classify_event(event)
        if not qualified:
            skipped.append((event.get("summary") or "Untitled", reason))
            continue
        child_input = PrepInput(mode="window", value=event.get("event_id"), window=prep_input.window)
        results.append(process_single(child_input, args, event=event))
    if not args.output_json:
        print()
        print("Window summary")
        print("| Event | Customer | Confidence | Doc |")
        print("| --- | --- | --- | --- |")
        for result in results:
            print(f"| {result.doc_title} | {result.customer_name or 'Unknown'} | {result.confidence} | {result.doc_url or 'local'} |")
        if skipped:
            print()
            print("Skipped events")
            for title, reason in skipped:
                print(f"- {title}: {reason}")
        if not results:
            print("No qualified customer meetings found.")
    return results


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    prep_input = prep_input_from_args(args)
    try:
        if prep_input.mode == "window":
            process_window(prep_input, args)
        else:
            process_single(prep_input, args)
        return 0
    except PrepError as exc:
        if args.output_json:
            print(json.dumps({"ok": False, "error": str(exc)}, indent=2))
        else:
            print(f"Prep run failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
